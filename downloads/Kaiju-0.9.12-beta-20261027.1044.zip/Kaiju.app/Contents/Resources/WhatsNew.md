## Kaiju 0.9.12 beta

- **Set list slot transpose:** Kaiju now reads and writes it. Set it in the slot's panel (Transpose); a transposed slot shows a small up or down chevron with the semitones.
- **Fix: transposed slots pointed at nothing.** Their combi or program wasn't found, and editing one lost part of the transpose. Both are fixed, and sorting or compacting banks keeps each slot's transpose.
- **Fix: slots playing a GM program** no longer jump to I-A 000 when Kaiju rewrites them (editing, importing, sorting).
- **Preview:** the slot's button starts hidden so the notes get the whole screen ("Show slot" brings it back), and the three suns try the KRONOS' notes brightness (a general setting of the keyboard, not saved in the PCG).
- **Welcome screen:** the "Continue" card has an × (and right-click › Remove from Recents), so a single recent file can be cleared too.
- **Convert to Nautilus (experimental):** set list slots whose program lands in a Nautilus bank a slot can't point at are now listed as unplaced instead of being written wrong.
- About: special thanks to Francis Capistrano (Narf @ NarfSounds), tester and advisor.
