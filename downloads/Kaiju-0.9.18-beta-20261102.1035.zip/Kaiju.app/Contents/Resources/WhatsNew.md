## Kaiju 0.9.18 beta

- **Signed and notarized by Apple:** Kaiju now opens like any app downloaded from the internet. No more "Open Anyway" in System Settings, and macOS stops asking again for access to your Desktop and Downloads folders after each update (it asks one last time with this version).
