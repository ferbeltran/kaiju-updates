## Kaiju 0.9.15 beta

- **Initialize, like the KRONOS:** every Erase / Empty command is now **Initialize** (Initialize…, Initialize slot, Initialize set list…, Initialize unused…), since Kaiju leaves the same "Init" entry the keyboard does.
- **Importing set lists:** the option that brings only the set lists is now called **Import Set Lists Only (No Sounds)**.
- **Import:** a PCG with only combis can be chosen as the library; ticking set lists (or anything else) keeps the places you chose by hand.
- **Convert to Nautilus (experimental):**
  - **MOD-7** programs now play the right ROM multisamples on the Nautilus (they kept the KRONOS numbers, so they played other samples). Checked against the Nautilus' own conversion and against sounds fixed by ear on a Nautilus.
  - On a Nautilus PCG, **"+"** offers the banks with the Nautilus names: combi banks **H–N**, program banks G–T / a–t, wave sequence banks B–T (combi bank H showed up as "U-A").
