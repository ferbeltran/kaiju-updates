## Kaiju 0.9.23 beta

- **Saved PCGs show as saved everywhere:** after editing and saving a PCG, **Import From**, the set list preview, "Used by" in Multisamples, "Copy a … here" and the other open PCGs see it as saved, without closing and reopening it (set lists added and saved now show up right away).
- **Pasting set list slots from another PCG plays the same sounds:** no more choosing between options. Sounds this PCG already has (in any slot) are pointed at; the combis and programs it doesn't have come along. Kaiju only asks before replacing slots that are in use.
- **"Save as" over a PCG that is open** now shows what was written, and isn't allowed while that PCG has unsaved changes.
- **Delete multisamples from a sample bank:** in Multisamples, right-click › **Delete from Bank…**, or when initializing programs or combis that were the only ones playing them. Each one leaves a silent "(deleted)" multisample with the same number, so the bank's UUID and every other multisample's number stay the same and no program points at the wrong sample. The files go to Kaiju's sample backups. The **Unused** button lists the multisamples no open PCG plays.
