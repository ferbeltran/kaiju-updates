## Kaiju 1.0

The first release of Kaiju: thanks to everyone who tested the betas.

- **Files in the cloud** (iCloud Drive, Dropbox, OneDrive, Google Drive) that aren't on your Mac yet are downloaded before Kaiju reads them. If one doesn't arrive, Kaiju tells you instead of waiting forever.
- **Cancel** while a file opens. If it takes longer than usual, Kaiju says why it might be.
- **Hold ⇧ Shift when Kaiju starts** to open it without reopening your files.
- **Sample Builder: loops and phrases on the same note** (they all read as C3) now go one per key, in file-name order, instead of overlapping.
- **Sample Builder: Correct tuning** can be turned off. When it's on, a detected note sets the Tune that puts the sample in tune (the audio isn't changed).
