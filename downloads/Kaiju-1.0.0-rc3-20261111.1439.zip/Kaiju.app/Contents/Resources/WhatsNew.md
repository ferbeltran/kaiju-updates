## Kaiju 1.0.0 RC3

- **New sample banks join the PCG they're made for:** in a PCG's **Multisamples** tab (or **File › New sample bank…** with a PCG on screen), the Sample Builder suggests saving next to that PCG, and once saved its multisamples appear in that PCG's own list, even before any program plays them. Kaiju remembers it when you open that PCG again.
- **A simpler welcome screen:** three cards, **Open…**, **New blank PCG** and **New sample bank** (one-shots or multisamples from WAV / AIFF files, without a PCG). Import, set lists and Global are a click away once your PCG is open.
- **New sample bank starts empty** once the previous one was saved (work not saved yet stays).
- **Unify the combis' default sound also takes tracks set to Off:** they never sound, but the keyboard shows them red when their program's samples aren't loaded (a KRONOS 2 library on a KRONOS X). Now they point at the default program you choose too.
- **Import: programs that don't fit can take the place of unused ones.** When there are no free slots left of their type, step 2 offers **Use N Unused Slots…**: they go over programs nothing in your PCG uses (no combi, set list or Drum Track), user banks first, then INT. You see the list and confirm first. When you choose a slot by hand, the programs nothing uses say **unused**.
- **Category view selects several sounds:** ⌘-click, ⇧-click or ⌘A, then copy, cut, initialize or change their category, even when they're in different banks.
- **Unused works in category view too:** it marks the programs of that category, from every bank, that no combi, set list or Drum Track uses.
- **Multisamples › This PCG counts only the sample banks it finds:** if the PCG's sounds use banks that aren't in its folder, the list says how many are missing instead of showing an empty count.
- **Buy Kaiju…** now goes through **kaijueditor.com/buy**.
- **The version shows RC3.**
