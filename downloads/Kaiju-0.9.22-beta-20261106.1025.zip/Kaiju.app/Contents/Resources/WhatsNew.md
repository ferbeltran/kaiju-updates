## Kaiju 0.9.22 beta

- **Initialized banks read as empty:** "Init" programs and combis that are identical to several others count as empty, even when the KRONOS that initialized them (another OS version) filled a parameter differently. A bank initialized on the keyboard no longer shows 128 used. A single edited "Init" still counts as used.
- **Sort part of a set list:** select several slots, right-click › **Sort N slots** › by name A→Z or Z→A. Only those slots are sorted, among their own positions; the rest of the set list stays put.
- **Dual View / Single View:** the button to see two set lists side by side is now called **Dual View** (and **Single View** to go back).
- **Color for several slots:** with several slots selected, the color is chosen from the same named grid as for one slot (Default, Charcoal, Brick…).
- **New sounds marked:** combis and programs you paste or import show a small **NEW** tag and a colored bar, and their bank a dot, until you close the PCG, so they're easy to find.
- **⌘C ⌘X ⌘V ⌘A and Delete in Programs and Combis** work reliably (they sometimes beeped).
