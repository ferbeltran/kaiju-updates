## Kaiju 0.9.20 beta

- **Set lists:** dropping slots you dragged no longer freezes for a moment; the drag ends right away and the new order stays.
- **Multisamples:** switching between the PCGs of a folder no longer moves the list a few pixels (the search field had extra space in PCGs without drum samples).
