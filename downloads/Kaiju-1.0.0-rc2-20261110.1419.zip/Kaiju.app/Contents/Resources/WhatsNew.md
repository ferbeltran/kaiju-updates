## Kaiju 1.0.0 RC2

- **Import single set list slots:** in **Import from another PCG › Set Lists**, the eye button (or right-click › **Show Slots…**) shows the set list as on the KRONOS, in pages of 16 slots with their colors; click the slots to bring and only those slots and their sounds come along. **Copy its EQ** (on unless you uncheck it) brings the set list's EQ too. In step 2 the slots can go to an empty set list, in the same numbers, or into the empty slots of one of your set lists in use (**In use — add to its empty slots**), which keeps its name and slots (and its EQ, if Copy its EQ is unchecked).
- **Double-click a .PCG to open it in Kaiju:** Kaiju now opens .PCG files and .KSC sample banks from Finder (or dropped on its Dock icon). If another app opens them, **Settings › Files › Make Kaiju the Default**.
- **Renamed programs are recognized:** importing a song whose combi this PCG already has (e.g. a single that is also in the full pack) no longer copies it again just because one of its programs was renamed in the pack: what a combi plays is compared by sound, not by name.
- **Continue reopens your whole session:** on the welcome screen, the Continue card opens every file you had open last time, not just the last one.
- **"Discard Changes"** is the new name of the Discard button.
- **Back up with Save PCG:** Kaiju now suggests **Disk › Save › Save PCG** (not Save All, which also writes empty KGE and SNG files and duplicates sample data).
- **The version shows RC2** in the status bar, About and What's New.
- Support is now at **support@kaijueditor.com**.
