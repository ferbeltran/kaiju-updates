## Kaiju 0.9.9 beta

- **Set list slot colors** are now the KRONOS' own 16 (Default, Charcoal, Brick, Burgundy, Ivy, Olive, Gold, Cacao, Indigo, Navy, Rose, Lavender, Azure, Denim, Silver, Slate), in its order and shades, and the slot's color picker is the KRONOS' 4 × 4 grid with their names. Before, Kaiju showed approximate colors (e.g. Charcoal looked red).
- **Rubber-band selection (⌥ + drag):** the cursor goes back to the arrow when you let go of ⌥; it stayed a crosshair.
- **Empty slots of the KRONOS 2 "RED SE" PRELOAD** (U-CC / U-DD 032–127) are recognised as empty, so Kaiju sees all the free space.
- With a long PCG name in a narrow window, the header buttons move to the second row instead of being cut short.
