## Kaiju 1.1 beta 2

### Songs
- **A Songs tab for each PCG:** when a .SNG is saved next to your PCG, Kaiju shows its songs. Double-click a song to open it, or choose another .SNG to see its songs with this PCG.
- **Edit a song's notes:** double-click a track to see its notes. Move a note or drag its end to change its length, double-click (or use the pencil) to add one, and delete the selected ones. Notes snap to the grid you choose. Scroll with two fingers or the mouse wheel and pinch to zoom.
- **Rename songs and tracks** with a click, and see each song's tempo.
- **⌘S saves the .SNG**, keeping a backup of the previous file in Kaiju's song backups.
- **Save as… takes the songs along:** the new PCG gets its .SNG with the same name, so Load All loads both on the KRONOS.
- **File › Open** also opens .SNG files.

### Set Lists
- **Assign a Song…** lists the songs by name. Without a .SNG, it asks you to choose one first, and you can still type the song number.
- **Right-click a slot's song › Open Song…** opens it.
