## Kaiju 0.9.16 beta

- **Rename and Category:** right-click a program or combi for **Rename…** (up to 24 characters, like on the keyboard) and **Category ›** (with several selected, it changes them all at once). KRONOS and Nautilus; ⌘Z undoes it.
- **Adding banks ("+"):**
  - **Add Missing Banks** at the top adds every bank the PCG doesn't have in one step (program banks as HD-1 or EXi).
  - The list comes in sections: on the Nautilus **A–T** and **a–t**; on the KRONOS INT, U-A…U-G and U-AA…U-GG.
  - **INT banks** can be added too when Settings › Files › "“+” also offers INT banks" is on. They keep their factory type, and Kaiju reminds you (in the menu and in the TXT saved with the PCG) that on the keyboard they may hold factory sounds: check before loading.
- **Set lists:** after **Initialize set list…** (or Undo / Redo) the name field shows the set list's real name; it kept the old one.
