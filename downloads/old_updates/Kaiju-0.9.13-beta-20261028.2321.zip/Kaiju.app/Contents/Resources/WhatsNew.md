## Kaiju 0.9.13 beta

- **Smart Transpose:** choose a transposed set list slot (or change its transpose) and, once you stop, a banner lists the sounds that won't play as intended: drum kits, cheat notes (timbres on 3 keys or fewer) and multisamples with one sample per key. Point at it to keep it open; the ⚠ next to Transpose brings it back.
- **Fix cheat notes in one step:** move their key zones by the transpose, or **Make a copy for this slot** — the combi goes to a free slot as "Name -2" with its zones moved, and only this slot plays it. Kaiju asks first when the combi plays in other slots. One Undo step.
- **Global Key Transpose** counts too: Set Lists shows a quiet note when the Global transposes everything, and the banner shows the total ("Transpose -1 (slot -3, Global +2)").
- **Help › KORG Files Explained:** what .PCG, .KSC, _UserBank.KSC, .KMP, .KSF, .SNG and .KGE are — including why a .KSC loads samples into RAM while its _UserBank.KSC streams them from the SSD. Also a card on the welcome screen.
- **Import fixes:**
  - a sound is never placed where the import keeps pointing (a timbre on an empty program could start playing something else);
  - imported set lists keep their EQ;
  - user scales already reused are never overwritten.
- The welcome screen's mini set list slots look like the editor's, and the 怪獣 KAIJU logo is the default.
