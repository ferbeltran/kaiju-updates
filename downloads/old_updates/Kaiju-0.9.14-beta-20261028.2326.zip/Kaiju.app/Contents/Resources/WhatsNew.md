## Kaiju 0.9.14 beta

- **Smart Transpose, checked on a KRONOS:** the slot transpose applies after the key zones, so splits and cheat notes are fine and no longer warned about. What's left to watch:
  - **drum kits** play other drums. **Fix: a copy for this slot** makes a copy of the combi ("Name -3") with only its drum kits transposed the other way, so every key plays its own drum again. Programs and key zones never change.
  - **one sample per key** multisamples and **wave sequences** are listed to check by ear; tick **Fix too** to transpose them back in the same copy.
- **Set list slots:**
  - transpose goes to ±24, like the KRONOS;
  - a slot with no name but a sound plays on the keyboard, so Kaiju keeps it when importing, copying and moving sounds, and shows it as "(no name)";
  - **Empty set list…** works on any set list that isn't factory-fresh, and is also in a ⋯ menu above the slots.
- **Preview:** note sizes XS, S and L measured on the keyboard.
- **The TXT saved with a PCG** now reads like a guide:
  - what the file replaces on your KRONOS (whole banks; partly used banks load the rest empty);
  - how to load it step by step with the keyboard's own screen names: a FAT32 USB stick, a Save All backup first, samples before the PCG, then everything, one part, one bank or one sound;
  - a checklist;
  - a slot-by-slot list of what's new, moved or replaced, and which set list slots changed.
- Muted timbres fade in the timbre editor, like Off ones (they don't sound).
- The sidebar counts follow the PCG after a save (they showed the file as first opened).
