## Kaiju 0.9.6 beta

- **Sample Builder (new):** make your own sample banks for the KRONOS from WAV, AIFF, MP3, M4A/AAC, FLAC or CAF files, or import SFZ and SoundFont (SF2) instruments. Samples go on their keys by the file's root key, its name ("Strings C3") or by listening to their pitch; a run of files recorded one semitone apart fills in by itself. Set root and top keys by pressing a key (⌥-click / ⇧-click), and edit each sample: trim, cut, fades, normalize, gain and loop points that snap to zero crossings, with a time ruler and vertical zoom. Saving writes the .KSC, its UserBank and the samples the way the KRONOS does, and adds the bank to your open files.
- **Edit samples of an existing bank** from the Multisamples tab (both sides of a stereo pair together). Kaiju keeps a copy of every original.
- **Convert MS to Program**, as on the KRONOS: right-click a multisample, pick any slot (an occupied one asks first). Select several multisamples (or the layers of an SFZ / SF2 instrument) to make one program with velocity layers MS1–MS8, even from different sample banks.
- **KRONOS / X ↔ KRONOS 2 / 3 factory order:** libraries made for the other order are adapted on import, so their combis play the right factory programs. Kaiju also follows factory programs you moved in your PCG, and tells you which ones you erased.
- **Nautilus:** save only some banks, add banks and add the set list section, written exactly as the Nautilus writes them.
- **Combis:** the number of tracks no longer counts the unused timbres factory combis park on the default piano. "Turn off unused timbres" switches them off in one click.
- **Import:** "Add bank" next to each bank in step 1; the import page starts empty every time; the slot picker shows the free slots left after what the import already uses.
- In a new blank PCG, options with nothing to work on show greyed out instead of disappearing.
- Fixes: a Kronos PCG could offer to add program banks that don't exist (U-14…U-33); the sidebar no longer jumps when it's shown again; "Clear" recent files asks first, and the list can be brought back from Settings; the About window shows complete.
