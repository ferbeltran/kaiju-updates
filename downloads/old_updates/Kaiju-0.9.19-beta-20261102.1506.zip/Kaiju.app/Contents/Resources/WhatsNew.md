## Kaiju 0.9.19 beta

- **Set lists, several slots at once:**
  - select several slots and change their **color, font size, volume or transpose** together, from the panel on the right (one Undo each);
  - **drag** a slot, or several selected ones, to reorder them: the other slots **make room as you go**, like icons on a phone, and dropping keeps that order.
- **Two set lists:** a new button next to Sort shows another set list next to the one you're editing. Drag slots between them to **copy** them: they go in where you drop them and the following ones move down.
- **Go to Combi / Go to Program:** right-click a set list slot to jump to the sound it plays and edit it.
