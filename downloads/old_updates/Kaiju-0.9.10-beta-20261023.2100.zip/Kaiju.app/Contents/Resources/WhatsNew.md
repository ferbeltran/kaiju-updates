## Kaiju 0.9.10 beta

- **Fix: playing samples could freeze the keyboard.** Now and then a key press in Multisamples left the keyboard stuck and silent, and Close no longer updated the sidebar. The audio engine is no longer rebuilt on every note, and a change of audio device (headphones, a call) is handled.
- **Sample Builder › Volume › Even out + normalize:** every sample is brought to the same loudness before the multisample is raised to full level, so one note recorded much louder no longer holds the others down. "Normalize" (raise it all as one, keeping the balance) is still there, and saving a big bank no longer freezes the window.
- **Delete a sample from an existing bank:** Multisamples › choose a zone › Delete…. Both sides of a stereo pair go, its keys go to the next zone, the other samples are numbered again, and the file and the bank as it was are kept in Kaiju's sample backups.
- **Compare two versions of a bank:** switching between open files keeps the same multisample and zone selected.
- **Convert to Nautilus (experimental):** Tools › Convert to Nautilus… writes a Nautilus PCG with a KRONOS PCG's programs, combis, wave sequences, drum kits and set lists, and says what it couldn't convert. Please try the result on a Nautilus before relying on it.
- Texts say KRONOS or Nautilus (following the PCG on screen) instead of "the keyboard".
- The sample bank's RAM total follows samples you edit or delete.
- Set list EQ: a taller graph, proportioned like the KRONOS'; the fader values fit a small window.
- App icons: the Set List and Combi looks come first; Flower is gone.
