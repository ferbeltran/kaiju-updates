## Kaiju 0.9.21 beta

- **Set lists from another PCG, pointing at your sounds:** when you paste set list slots copied from another PCG, the new option **Paste pointing at the sounds already here** finds each combi or program in your PCG wherever it is now (for example, combis you imported and moved). It matches the same sound, or else the only one with the same name; nothing is imported, and the notes and colors stay.
- **"Copied" notices:** copying or cutting programs, combis, wave sequences, drum kits, set list slots or set lists shows a short notice at the bottom of the window ("4 set list slots copied").
- **Slot names as you type:** the name shows on the slot while you type it, and choosing another slot keeps what you typed (no need to press Enter).
- **Init programs no longer counted as used:** "Init" programs whose Drum Track points at another program (as some saves write them) read as empty, so bank counts and Unused are right.
- **Saved PCGs as a source:** after saving a PCG in Kaiju, importing or pasting from it uses what you saved, without reopening it.
