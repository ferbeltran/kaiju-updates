## Kaiju 0.9.4 beta

- **Save only some banks, like the Kronos does.** "Save as new PCG…" now has the Kronos "Save PCG Data" page: tick banks of each type, Global settings, Drum Track patterns and set lists. If a ticked sound uses a bank you left out, Kaiju tells you and can add it.
- **New blank PCG** (File menu): starts from your PCG's Global and INT banks with every user bank and set list empty. Fill it, then save just the banks you used.
- **Build and edit combis.** Right click an empty combi slot › New combi here…, then "Add track" to put programs on its timbres. "Edit timbres & zones…" sets status, MIDI channel, mute, volume, pan, transpose and the key and velocity zones on a keyboard. Each MIDI channel gets its own colour, so layers and splits that play together are easy to spot.
- **Import:** untick a program a combi brings to leave its timbres pointing at that slot (when the keyboard already has it), and tick programs in "Not imported" to bring them too.
- **Category view** in Programs and Combis (and when choosing a program), like Category Select on the Kronos.
- **Set lists:** copy and paste a whole set list (with its sounds when it comes from another PCG), assign a combi or program from a slot's right-click menu, empty a set list, a preview of the slot with its colour and font size, and a bigger window for the notes.
- **Move or copy a sound into an empty slot** from its right-click menu, without going to the original first.
- **Add a missing bank** with the "+" next to the bank buttons, and when changing a bank's type, choose where its programs go (or split them across two banks).
- **Unused programs:** untick the ones you want to keep before erasing.
- **Rename the category names** in the Global tab.
- Kronos 3 PCGs checked. Sample files whose names changed when copied (an apostrophe that became "_") are found, with a warning that the keyboard won't load them as they are.
- If Kaiju quit unexpectedly, it offers to send the report next time (your user name and folders are hidden; no PCG goes in).
- Fixes: Kaiju could open with no window after being force-quit; spacing in the Global tab; EXi labels are green and no longer squeezed; the empty sample bank the Kronos writes by default isn't counted.
