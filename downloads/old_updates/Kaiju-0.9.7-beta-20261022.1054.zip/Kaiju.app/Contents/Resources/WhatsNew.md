## Kaiju 0.9.7 beta

- **Optimize space (new):** gathers the sounds of the user banks of each type (HD-1 and EXi programs, combis, wave sequences, drum kits) at the start, so the gaps end up together and whole banks free up. It shows what it will free before doing anything; combis, set lists and Drum Tracks follow their sounds.
- **Duplicates (new):** finds programs that are exactly the same sound (same name, same settings, same drum kits and wave sequences), keeps one of each and points everything that used the copies to it. Programs that only share a name are left alone.
- **Init Bank (new):** right-click a user bank to empty it, or all user banks at once, for a blank slate that keeps your INT banks. It lists what uses those sounds first.
- **New blank PCG** asks whether it's for the KRONOS or the Nautilus.
- **Keyboard shortcuts** panel in the Help menu (⌘/).
- **Status bar:** shows which keyboard the open PCG is for (KRONOS / KRONOS X, KRONOS 2 / 3 or Nautilus).
- **Combis:** the track count now recognises the program a PCG parks its unused timbres on, whatever slot or name it has: your own piano on I-A 000, or a KRONOS 3 piano imported into a user slot.
- **Save As** is always available and can save over the original file (Kaiju keeps a backup of it).
- Fixes: the selection clears after erasing slots, so the side panel and the "selected" count no longer show slots that are gone.
