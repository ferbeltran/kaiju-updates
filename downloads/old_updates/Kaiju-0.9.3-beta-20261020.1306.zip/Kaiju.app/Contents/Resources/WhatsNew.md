## Kaiju 0.9.3 beta

- **A new welcome screen.** The file you worked on last is at the top with a peek at its first set list; your drives are listed one line each (unfold to see their PCGs, eject from there); recent files show what's inside; plus tips and what's new.
- **WS & Drums is fixed.** Clicking a wave sequence or drum kit selects it again, and the tab no longer slows down with big libraries.
- **Nautilus PCGs open read-only.** You can browse their combis, programs, set lists, arpeggio patterns and Global; editing comes once it's tested on the keyboard. Files Kaiju doesn't recognise also open read-only instead of failing.
- **Samples found more often.** A PCG opened from Desktop, Documents or Downloads now finds its .KSC in a folder with a similar name ("80s Booster V2.PCG" next to "80s Booster Sample Data").
- **No more orange dots on factory sounds.** Sounds that use the factory EXs every Kronos loads (ROM Expansion, ROM Expansion 2…) or GM programs now show as factory. The orange "EXs not loaded" only appears when the .KSC load script next to the PCG leaves out an EXs the sound needs, and a program's details name the EXs it uses.
- **Sample badges fixed** for PCGs saved with older Kronos OS versions.
- Combis is now the first tab, and "Licensed to" shows on the welcome screen and the status bar.
