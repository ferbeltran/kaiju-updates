## Kaiju 0.9.11 beta

- **Set lists look like the KRONOS screen:** the yellow bar over the slots shows the slot you're editing (name, sound and notes, before you apply them), slots come 4 per row in their full colors, and the font sizes are XS, S, M, L and XL as the KRONOS stores them.
- **Preview:** the button in a slot's panel shows the slot on the KRONOS' Set List screen, with the notes at the size the keyboard uses and cut where it cuts them. "Hide slot" appears when the notes reach the slot's button.
- **Tools › Set list slots that play nothing:** finds slots pointing at an empty combi or program, or at a user bank this PCG doesn't have, and empties the ones you tick in one step (Undo brings them back).
- **EXi engines:** an EXi program's panel shows its engines (for example SGX-2 + MOD-7), and Organize › Sort › Sort by engine groups an EXi bank by engine. HD-1 / EXi is now called "Bank type".
- **Drum Track patterns:** select several and delete them, or delete the unused ones or all of them.
- **Import:**
  - the bank picker shows where things will go, and choosing another bank moves them there;
  - the bank buttons land on the bank with one click;
  - INT banks can be destinations, and adding missing banks no longer freezes the window;
  - Set Lists shows only the chosen PCG's set lists;
  - "Continue editing PCG" takes you to where the import went.
- ⌘C, ⌘X and ⌘V always work on the selected set list slots (⌘V sometimes did nothing).
- Kaiju opens at about 1580 × 1200 (or most of a smaller screen).
- The header buttons no longer jump on the first edit, and "Save as new PCG…" is now "Save as…".
- Recent files lists only PCGs, sample banks and folders.
- Fix: sorting an INT bank no longer changes empty combis that point at it.
