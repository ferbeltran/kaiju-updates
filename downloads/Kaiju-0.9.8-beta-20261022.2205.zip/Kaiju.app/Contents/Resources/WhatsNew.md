## Kaiju 0.9.8 beta

- **Unify the combis' default sound (new, Tools menu):** a master PCG made from several libraries parks unused timbres on each library's own default program (e.g. a KRONOS 3 Berlin Grand), which shows red tracks with "Samples not loaded" on a keyboard without it. Kaiju points them all at the program you choose. Only timbres that can't sound change, so no combi sounds different.
- **Erase combis and their programs (new):** when erasing combis, a second button also empties the programs only those combis use (and the wave sequences / drum kits only those use). Anything another combi, set list or Drum Track uses stays; factory banks are never touched. One Undo step.
- **Import set lists without the rest:** "Only sounds already in this PCG" brings a set list pointing at the combis you already have and leaves its other slots empty, for "light" PCGs. Each set list shows how many slots stay empty.
- **Combis imported earlier are recognised in any slot,** so importing a set list later doesn't copy them again.
- **Paste and "Bring here" from another PCG** follow the factory programs you moved in your PCG and adapt the KRONOS / X ↔ 2 / 3 order, as Import does.
- **Each open PCG keeps its own import:** look at another PCG and come back, the import is as you left it.
- **Import step 1:** a bank index above the list jumps straight to a bank.
- **Multisamples tab:** shows only the sample banks this PCG plays; other banks in the same folder appear apart ("Others in the folder").
- **"+" to add a bank** is now a round button, appears even when a PCG has no user banks of that kind (e.g. a library's combis), and works with only that PCG open.
- **Window:** opens larger (most of the screen), with a minimum size where nothing overlaps; toolbars and buttons rearrange in a narrow window.
- Multisamples: zones without a sample ("SKIPPEDSAMPL") show as silent keys; a black-key zone is outlined only over that key.
