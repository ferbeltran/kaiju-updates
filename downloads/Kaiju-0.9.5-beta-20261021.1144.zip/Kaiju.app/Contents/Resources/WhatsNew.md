## Kaiju 0.9.5 beta

- **Nautilus support.** Nautilus PCGs now open for editing: import sounds and set lists between Nautilus PCGs, move, swap and erase, edit combis, set lists and Global. Banks show the Nautilus names (A–T and a–t). For now the whole PCG is always saved; adding banks and saving only some banks are still Kronos-only.
- **Rubber-band selection:** hold ⌥ (Option) and drag over the slots to select several at once (add ⇧ to keep what was selected).
- **Play the samples:** in Multisamples, click a key to hear its zone's sample at that pitch. "Big keys" makes the keyboard wider to play it more comfortably.
- **New blank PCG** no longer asks for a PCG to base it on: it starts from scratch.
- Combis count their muted timbres too (Session Keys shows 8T instead of 1T).
- Fixes: full screen and maximized windows no longer hide buttons or cut off the top; switching tabs no longer moves the window; the Set Lists view keeps its buttons when maximized.
