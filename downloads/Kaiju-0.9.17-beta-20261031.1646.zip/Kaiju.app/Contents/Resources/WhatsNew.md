## Kaiju 0.9.17 beta

- **Welcome:** a **Welcome** row at the top of the sidebar goes back to the welcome screen (recent files, Import, New blank PCG…) without closing your PCGs; clicking a PCG returns to it on the same tab.
- **Clearer wording:**
  - moving a sound to a bank of the other type now says **Incompatible Bank Type** and how to fix it;
  - the panel for several selected slots: **Copy (⌘C)**, **Cut to Move (⌘X)**, **Initialize (⌫)**, what each one does, and the selection shortcuts;
  - right-click menus say **Cut to Move**;
  - changing a bank's type (HD-1 / EXi) says that it initializes all the programs in the bank, and that ⌘Z undoes it.
- While a PCG loads, the mascot shows centered (for a moment it appeared stuck at the left).
