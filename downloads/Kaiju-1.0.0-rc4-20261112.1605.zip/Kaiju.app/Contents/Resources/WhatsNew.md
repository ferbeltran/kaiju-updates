## Kaiju 1.0.0 RC4

- **Dual View: the other Set List selects too:** click, ⌘-click or ⇧-click its slots (a quieter outline), ⌘A, ⌘C, or drag several at once into the Set List you're editing. ⌘X and ⌫ there never touch the one you're editing.
- **The selected slot is yellow,** as on the KRONOS.
- **Combi, Set List and Program are capitalized** everywhere, as in the KRONOS manuals.
- **Tooltips show sooner,** and the buttons that had none now explain what they do.
- **Import fills empty slots that nothing points at first:** an empty slot a Set List slot, a muted track or a Drum Track points at is used last, so it doesn't suddenly start playing an imported sound.
- **Use Unused Slots never offers a Program the import itself still plays** (a muted track, a Drum Track or a Set List slot that stays pointing at your PCG).
- **An empty Drum Track Program points at an empty slot of your PCG** after the import, so it stays silent as before.
- **Convert to Nautilus** asks for a licence or the trial, like Save as.
- **Import no longer brings an empty Drum Track Program** (it showed as "Init Program" among the Programs to copy).
- **Delete (⌫) initializes the selected Set List slots** wherever you clicked last (it used to only beep).
- **Dragging several Set List slots onto one of their own** moves the block there: the slot you grabbed lands where you let go (10–14 grabbed by 10 and dropped on 13 → 13–17).
- **New theme: Darker** (Settings › Appearance), a deep cool slate with macOS's high-contrast controls.
- **The installer window** shows an arrow from Kaiju to Applications.
- **The version shows RC4.**
