## Kaiju 1.1 beta 1

### Combis
- **Combis open in their own window, laid out like the KRONOS:** double-click a Combi (or right-click › Details…). Prog Select/Mixer with faders and pan knobs, Timbre EQ, MIDI, Key Zones, Scenes and Audio In, drawn like the KRONOS' panel. Every change is one Undo step. The arrows next to the category go to the previous / next Combi.
- **Copy and reorder tracks:** drag a track's number or Program onto another to move it (everything moves with it: Program, mixer, zones, EQ, filters, effects routing), or right-click › Copy Tn to.
- **Rename a track's Program** from the Combi, and add the track numbers to the Program names ("Fame Brass T1"), with a preview first.
- **MIDI Filter pages:** Program Change, After Touch, Damper, joystick, ribbon, knobs, switches, pedals… per track, as on the KRONOS.
- **Scenes:** a Combi without scenes says so, warns when its KARMA plays patterns, and sets them up in one click.
- **Audio In:** each Combi's audio inputs (AUDIO IN 1/2, USB L/R, S/P DIF L/R): Use Global Setting, or its own bus, level, pan and sends. The Global tab has the Global ones.
- **Key zones in the Combi panel:** drag a track's bar, or its edges, to change where it plays.

### Set Lists and Songs
- **Find a song in every Set List** by its name, its sound or its notes.
- **Set List slots can play a Song** of the sequencer (right-click › Assign a Song…). Kaiju shows the song names from the .SNG saved with your PCG.
- **Import Songs from a library:** a .SNG only stores the program number each track plays, not the sound. Choose a library's .SNG and Kaiju uses the library's original PCG to see which sound each number was, finds it in your PCG (even if you moved or compacted it), and adds the songs to your PCG's own .SNG pointing where your PCG keeps each sound. It tells you, song by song, what is in its place, what moved, what is another version and what is missing. Load your PCG and its .SNG together on the KRONOS (Load All).

### Import
- **Fixed:** with "Keep the library's slot" off, sounds now go from the slot you chose, even if the library uses those slots (they went to 051–054 instead of 000–003 on a Nautilus).

### Sample Builder
- **Drag samples to reorder them** (the one you drag takes the keys of the place you drop it on), and **Undo / Redo** (⌘Z / ⇧⌘Z).

### Other
- **Clearer message for samples Kaiju can't find:** "This Program uses external samples that weren't found. They may already be loaded on your KRONOS."
- Betas have a BETA band on their icon.
